﻿namespace Academy.Models.Enums
{
    public enum Grade
    {
        Excellent = 0, 
        Passed = 1,
        Failed = 2
    }
}
