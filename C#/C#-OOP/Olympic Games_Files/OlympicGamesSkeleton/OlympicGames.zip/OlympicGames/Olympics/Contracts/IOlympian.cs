﻿namespace OlympicGames.Olympics.Contracts
{
    public interface IOlympian
    {
        string FirstName { get; }

        string LastName { get; }
    }
}
