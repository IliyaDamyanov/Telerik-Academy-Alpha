﻿namespace Traveller.Models.Vehicles
{
    public enum VehicleType
    {
        Land = 0,
        Air = 1,
        Sea = 2
    }
}
