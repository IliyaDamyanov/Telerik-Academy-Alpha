﻿namespace OlympicGames.Core.Contracts
{
    public interface ICommand
    {
        string Execute();
    }
}
